import sys, os
from skillshare import Skillshare, splash

cookie = '\n"device_session_id=55318d3b-b57f-4def-bf92-4bd095360c9d; show-like-copy=0; YII_CSRF_TOKEN=bXRFNzdVa0Rqd0Rlbjc4TEROczBWU1gzdnMwWm41NjDWjZ2a040pGUS7tfpqbgoUpfli5cMHfzAQY_QRZnM-Qg%3D%3D; visitor_tracking=utm_campaign%3D%26utm_source%3D%28direct%29%26utm_medium%3D%28none%29%26utm_term%3D%26referrer%3D%26referring_username%3D; first_landing=utm_campaign%3D%26utm_source%3D%28direct%29%26utm_medium%3D%28none%29%26utm_term%3D%26referrer%3D%26referring_username%3D; G_ENABLED_IDPS=google; __stripe_mid=b90b6441-642d-466c-9894-cd802cc179b348c2ba; CAPTIONS=off; __stripe_sid=72a0e95a-11cd-45a2-aeca-6d3134b3c50e9c2c73; ss_hide_default_banner=1644428554.512; __cf_bm=3e47c14c87d9f63cb289998f3d4a829c9db9aa15-1628950112-1800-AZbxNWZF/t06H//tEqXuM282Fh35hfvgSIGju7MX2VpUw5IyQEatM90WDSfdIop/drDQBkUygkuzXZapTojXsn8OWTmYBDmyiH+IQtjEM52QPPFxfolunT/nABoNQsOdDOhDAp0HZFPOUcBlOqgejnacfqptZqdIedJ3rcRK+3hKnseEoJCXn07mgPAMW4J4pQ==; PHPSESSID=acc01f96cc169cb765b5ab9127bdf0ed; skillshare_user_=d5ec6938c823d91710a537d3b300942ee5963dafa%3A4%3A%7Bi%3A0%3Bs%3A8%3A%2223841710%22%3Bi%3A1%3Bs%3A21%3A%22easyblog8%40outlook.com%22%3Bi%3A2%3Bi%3A7776000%3Bi%3A3%3Ba%3A4%3A%7Bs%3A8%3A%22username%22%3Bs%3A9%3A%22335428663%22%3Bs%3A10%3A%22login_time%22%3Bs%3A19%3A%222022-02-06%2008%3A53%3A10%22%3Bs%3A10%3A%22touch_time%22%3Bs%3A19%3A%222022-02-19%2019%3A30%3A15%22%3Bs%3A5%3A%22roles%22%3Bs%3A0%3A%22%22%3B%7D%7D"\n'

# or by class ID:
# dl.download_course_by_class_id(189505397)

def main():
    dl = Skillshare(cookie)
    course_url = sys.argv[1]
    dl.download_course_by_url(course_url)


if __name__ == "__main__":
    splash()
    main()
